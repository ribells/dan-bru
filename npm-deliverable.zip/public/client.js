import * as THREE from '/build/three.module.js';

var scene = new THREE.Scene();
var group = new THREE.Group();
var targetRotation = 0;
var targetTranslation = 0;
var targetRotationOnMouseDown = 0;
var mouseX = 0;
var mouseY = -1;
var prevMouseY = -1;
var mouseXOnMouseDown = 0;
const windowHalfX = window.innerWidth / 2;
const windowHalfY = window.innerHeight / 2;

const restDistance = 1;
const xSegs = 400;
const ySegs = 300;
var sphere = "";
const ballSize = 30;
var submerged = false;
var diff = new THREE.Vector3();

function plane( width, height ) {
	return function ( u, v, target ) {
		const x = ( u - 0.5 ) * width;
		const y = ( v + 0.5 ) * height;
		const z = 0;
		target.set( x, y, z );
	};
}

const geometryFunction = plane( restDistance * xSegs, restDistance * ySegs );

class Particle {
	constructor( x, y, z, mass) {
		this.position = new THREE.Vector3();
		this.previous = new THREE.Vector3();
		this.original = new THREE.Vector3();
		this.a = new THREE.Vector3( 0, 0, 0 ); // acceleration
		this.mass = mass;
		this.invMass = 1 / mass;
		this.tmp = new THREE.Vector3();
		this.tmp2 = new THREE.Vector3();

		// init
		geometryFunction( x, y, this.position ); // position
		geometryFunction( x, y, this.previous ); // previous
		geometryFunction( x, y, this.original );
	}

	// Force -> Acceleration
	addForce( force ) {
		this.a.add(
			this.tmp2.copy( force ).multiplyScalar( this.invMass )
		);
	}

	// Performs Verlet integration
	integrate( timesq ) {
		const newPos = this.tmp.subVectors( this.position, this.previous );
		newPos.multiplyScalar( DRAG ).add( this.position );
		newPos.add( this.a.multiplyScalar( timesq ) );

		this.tmp = this.previous;
		this.previous = this.position;
		this.position = newPos;

		this.a.set( 0, 0, 0 );
	}
}

class Terrain {
	constructor(_x, _y, THREE) {
		this.num_lon    = _x;    // number of longitude steps
		this.num_lat    = _y;    // number of latitude steps
		this.height_map = [];    // two-dimensional array of elevations
		this.geometry   = "";	

		this.particles = [];
		this.constraints = [];
		this.VISCOSITY = 10;
		this.MASS = 0.04;
	}			
	
	generate = function ()
	{
		// Create particles for terrain
		for (let v=0; v<=this.num_lat; v++) {
			for ( var u = 0; u <= this.num_lon; u ++ ) {
				this.particles.push(
					new Particle( u / this.num_lon, v / this.num_lat, 0, this.MASS )
				);
			}
		}

		// Structural
		for ( let v = 0; v < this.num_lat; v ++ ) {
			for ( let u = 0; u < this.num_lon; u ++ ) {
				this.constraints.push( [
					this.particles[ index( u, v, this.num_lon ) ],
					this.particles[ index( u, v + 1, this.num_lon ) ],
					restDistance
				] );

				this.constraints.push( [
					this.particles[ index( u, v, this.num_lon ) ],
					this.particles[ index( u + 1, v, this.num_lon ) ],
					restDistance
				] );
			}
		}

		for ( let u = this.num_lon, v = 0; v < this.num_lat; v ++ ) {
			this.constraints.push( [
				this.particles[ index( u, v, this.num_lon ) ],
				this.particles[ index( u, v + 1, this.num_lon ) ],
				restDistance
			] );
		}

		for ( let v = this.num_lat, u = 0; u < this.num_lon; u ++ ) {
			this.constraints.push( [
				this.particles[ index( u, v, this.num_lon ) ],
				this.particles[ index( u + 1, v, this.num_lon ) ],
				restDistance
			] );
		}

		function index( u, v, x) {
			return u + v * (x + 1 );
		}
		this.index = index;

		//generate the terrain;
		for(let y = 0; y<this.num_lat; y++) {
		   var row = [];
		   for(let x = 0; x<this.num_lon; x++) {
			  row.push(Math.random()*2);
		   }
		   this.height_map.push(row);
		}
	}
	
	visualize = function ()
	{
		this.geometry = new THREE.ParametricBufferGeometry( geometryFunction, this.num_lon, this.num_lat );
		var material = new THREE.MeshNormalMaterial(0xffff00ff);
		var mesh = new THREE.Mesh(this.geometry, material);
		
		const p = this.particles;
		for ( let i = 0, il = p.length; i < il; i ++ ) {
			const v = p[ i ].position;
			if(Math.floor(i/this.num_lon) < 300) {
				v.z = this.height_map[Math.floor(i/this.num_lon)][i % this.num_lon];
			}
			this.geometry.attributes.position.setXYZ( i, v.x, v.y, v.z );
		}
		this.geometry.attributes.position.needsUpdate = true;
		this.geometry.computeVertexNormals();
						
		return mesh;
	}
	
	perturb = function (ball, ballSize)
	{
		if(!submerged) {
			ball.position.z -= 1;
		} else {
			ball.position.x += 6*Math.random()-3;
			ball.position.y += 6*Math.random()-3;
			ball.position.z += 6*Math.random()-3;
		}
		if(ball.position.z < ballSize/4) {
			submerged = true;
			ball.position.z = ballSize/4;
		} else if(submerged && ball.position.z > ballSize*1.1) {
			ball.position.z = ballSize*1.1;
		}
		
		//update for collision with ball
		for ( let i = 0, il = this.particles.length; i < il; i ++ ) {
			const particle = this.particles[ i ];
			const pos = particle.position;
			diff.subVectors( pos, ball.position );
			
			// collided
			if ( diff.length() < ballSize ) {
				diff.normalize().multiplyScalar( ballSize );
				pos.copy( ball.position ).add( diff );
				this.geometry.attributes.position.setXYZ( i, pos.x, pos.y, pos.z );
			} else {
				//elasticity based on viscosity of terrain
				if(Math.floor(i/this.num_lon) < 300) {
					if(pos.z < this.height_map[Math.floor(i/this.num_lon)][i % this.num_lon]) {
						pos.z -= (pos.z - this.height_map[Math.floor(i/this.num_lon)][i % this.num_lon])/100;
						pos.x -= (pos.x - particle.original.x)/this.VISCOSITY;
						pos.y += (particle.original.y - pos.y)/this.VISCOSITY;
						this.geometry.attributes.position.setXYZ( i, pos.x, pos.y, pos.z );
					}
				}					
			}
		}				
		this.geometry.attributes.position.needsUpdate = true;
		this.geometry.computeVertexNormals();
		return ball.position;
	}
	
	interact = function () 
	{
	}
	
	perform_analysis = function ()
	{
		//perform the analysis of the geometry created;
		return true;
	}
}		

///Renderer
var renderer = new THREE.WebGLRenderer( { antialias: true } );
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

///background
renderer.setClearColor ("#ddccff", 1);

var scene = new THREE.Scene();

///camera
var camera = new THREE.PerspectiveCamera(35, window.innerWidth/window.innerHeight, 1, 10000 );
camera.position.set( 0, 300, 1600 );
camera.lookAt( 0, 300, 0 );
camera.zoom = 3;
scene.add( camera );

function render() {
	camera.updateProjectionMatrix();
	group.rotation.y += ( targetRotation - group.rotation.y ) * 0.05;
	if(group.rotation.y > Math.PI/4) {
		group.rotation.y = Math.PI/4;
	} else if (group.rotation.y < -Math.PI/4) {
		group.rotation.y = -Math.PI/4;
	}
	group.position.z += ( targetTranslation );
	if (group.position.z < -100) {
		group.position.z = -100;
	} else if (group.position.z > 0) {
		group.position.z = 0;
	}
  
	if(sphere) {
	  	var pos = terrain.perturb(sphere, ballSize);
	}
	proxy.position.x = pos.x;
	proxy.position.y = pos.y;
	proxy.position.z = pos.z;
	renderer.render(scene, camera);
	requestAnimationFrame(render);
}

///lighting & shadows
var lightA1 = new THREE.AmbientLight(0xFF00FF, 0.85);
scene.add(lightA1);
var lightD1 = new THREE.DirectionalLight( 0xFFFFFF, 0.85 );
lightD1.position.set( -20, 600, -20 );
lightD1.castShadow = true;
scene.add( lightD1 );
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

scene.add(group);

var terrain = new Terrain(400, 300, THREE);
terrain.generate();
var mesh = terrain.visualize();
scene.add(mesh);

// sphere
const ballGeo = new THREE.SphereGeometry( ballSize, 32, 16 );
const ballMaterial = new THREE.MeshBasicMaterial(0xffff00);

sphere = new THREE.Mesh( ballGeo, ballMaterial );
sphere.visible = false;
sphere.position.set(0, 300, 50);
group.add(sphere);

// sphere-proxy
const proxyGeo = new THREE.SphereGeometry( ballSize*.8, 32, 16 );
const proxyMaterial = new THREE.MeshLambertMaterial(0xffff00);
var proxy = new THREE.Mesh( proxyGeo, proxyMaterial );
proxy.castShadow = true;
proxy.receiveShadow = true;
proxy.position.set(0, 300, 50);
group.add(proxy);
	
render();

function onDocumentMouseDown( event ) {
	event.preventDefault();
	document.addEventListener( 'mousemove', onDocumentMouseMove, false );
	document.addEventListener( 'mouseup', onDocumentMouseUp, false );
	document.addEventListener( 'mouseout', onDocumentMouseOut, false );
	mouseXOnMouseDown = event.clientX - windowHalfX;
	targetRotationOnMouseDown = targetRotation;
}

function onDocumentMouseMove( event ) {
	mouseX = event.clientX - windowHalfX;
	if(prevMouseY == -1) {
		prevMouseY = event.clientY;
		mouseY = event.clientY;
	} else {
		prevMouseY = mouseY;
		mouseY = event.clientY;
		targetTranslation = (mouseY - prevMouseY);
	}
	targetRotation = targetRotationOnMouseDown + ( mouseX - mouseXOnMouseDown ) * 0.02;
}

function onDocumentMouseUp( event ) {
	document.removeEventListener( 'mousemove', onDocumentMouseMove, false );
	document.removeEventListener( 'mouseup', onDocumentMouseUp, false );
	document.removeEventListener( 'mouseout', onDocumentMouseOut, false );
	prevMouseY = -1; mouseY = -1;
}

function onDocumentMouseOut( event ) {
	document.removeEventListener( 'mousemove', onDocumentMouseMove, false );
	document.removeEventListener( 'mouseup', onDocumentMouseUp, false );
	document.removeEventListener( 'mouseout', onDocumentMouseOut, false );
}

document.addEventListener( 'mousedown', onDocumentMouseDown, false );

